// Hide loading screen after 2 seconds
window.onload = () => {
  setTimeout(() => {
    document.getElementById("loading-screen").style.display = "none";
  }, 2000);
};

// Product storage
let products = [];

// Show Admin Login Form
function showAdminLogin() {
  document.getElementById("admin-login").classList.remove("hidden");
  document.getElementById("user-mode").classList.add("hidden");
  document.getElementById("admin-mode").classList.add("hidden");
}

// Login Function
function loginAdmin() {
  const email = document.getElementById("admin-email").value;
  const password = document.getElementById("admin-password").value;

  if (email === "ajlalbhatti371@gmail.com" && password === "bhatticorporation707ajlal") {
    document.getElementById("admin-login").classList.add("hidden");
    document.getElementById("admin-mode").classList.remove("hidden");
  } else {
    alert("❌ Wrong email or password!");
  }
}

// Show User Mode
function showUserMode() {
  document.getElementById("user-mode").classList.remove("hidden");
  document.getElementById("admin-login").classList.add("hidden");
  document.getElementById("admin-mode").classList.add("hidden");
  displayProducts();
}

// Add Product
function addProduct() {
  const name = document.getElementById("product-name").value;
  const imageInput = document.getElementById("product-image");
  const image = imageInput.files[0];

  if (name && image) {
    const reader = new FileReader();
    reader.onload = function(e) {
      const product = { name: name, image: e.target.result };
      products.push(product);
      displayProducts();
      displayAdminProducts();
    };
    reader.readAsDataURL(image);
  } else {
    alert("Please add product name and image.");
  }
}

// Display for User
function displayProducts() {
  const list = document.getElementById("product-list");
  list.innerHTML = "";
  products.forEach(p => {
    list.innerHTML += `
      <div class="product">
        <img src="${p.image}" alt="${p.name}">
        <h3 class="neon-text">${p.name}</h3>
      </div>`;
  });
}

// Display for Admin
function displayAdminProducts() {
  const list = document.getElementById("admin-products");
  list.innerHTML = "";
  products.forEach((p, index) => {
    list.innerHTML += `
      <div class="product">
        <img src="${p.image}" alt="${p.name}">
        <h3>${p.name}</h3>
        <button onclick="deleteProduct(${index})">🗑 Delete</button>
      </div>`;
  });
}

// Delete Product
function deleteProduct(index) {
  products.splice(index, 1);
  displayProducts();
  displayAdminProducts();
}

// Search Function
function searchProducts() {
  let input = document.getElementById("search-bar").value.toLowerCase();
  let items = document.querySelectorAll("#product-list .product");

  items.forEach(item => {
    let name = item.querySelector("h3").textContent.toLowerCase();
    item.style.display = name.includes(input) ? "block" : "none";
  });
}
